"""Kālsangati test suite."""
